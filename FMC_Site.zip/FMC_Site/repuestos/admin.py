from django.contrib import admin
from .models import Articulo

admin.site.register(Articulo)


