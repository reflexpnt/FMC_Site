from django.apps import AppConfig


class RepuestosConfig(AppConfig):
    name = 'repuestos'
